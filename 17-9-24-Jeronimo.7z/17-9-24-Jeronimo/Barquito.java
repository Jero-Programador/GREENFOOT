import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class Barquito here.
 * 
 * @author Jerónimo Arroyave 
 * @version (a version number or a date)
 */




public class Barquito extends Actor
{
    /**
     * Act - do whatever the Barquito wants to do. This method is called whenever
     * the 'Act' or 'Run' button gets pressed in the environment.
     */
    
    public Barquito(int cantidad){
        setRotation(cantidad);
    }
    Boolean canFire = true;
    public void act()
    {
        if (Greenfoot.isKeyDown("d")){
            setLocation(getX()+5, getY());
            setRotation(360);
        }
        if (Greenfoot.isKeyDown("a")){
            setLocation(getX()-5, getY());
            setRotation(180);
        }
        if (Greenfoot.isKeyDown("w")){
            setLocation(getX(), getY()-5);
            setRotation(270);
        }
        if (Greenfoot.isKeyDown("s")){
            setLocation(getX(), getY()+5);
            setRotation(90);
        }
        fireProjectile();
        // Add your action code here.
    }
    public void fireProjectile()
    {
        if(Greenfoot.isKeyDown("space") && canFire == true){
            getWorld().addObject(new Proyectil(), getX(), getY()-30);
            canFire = false;
           
        } else if(!Greenfoot.isKeyDown("space")){
            canFire =true;  
        }

    }
}

